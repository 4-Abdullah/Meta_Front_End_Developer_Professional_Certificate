import { Heading, HStack, Image, Text, VStack } from "@chakra-ui/react";
import { CardBody, Card as ChakraCard } from "@chakra-ui/card";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  // Implement the UI for the Card component according to the instructions.
  // You should be able to implement the component with the elements imported above.
  // Feel free to import other UI components from Chakra UI if you wish to.
  return (
    <ChakraCard backgroundColor="white" borderRadius="lg">
      <CardBody color="black" margin="5">
        <Image src={imageSrc} borderRadius = 'lg'></Image>
        <VStack align="left" marginTop='6'>
          <Heading size='sm'>{title}</Heading>
          <Text fontSize='sm' color="grey">{description} </Text>
          See more
          <HStack>
            <Text fontSize='sm'>See more </Text>
            <FontAwesomeIcon icon={faArrowRight} size="1x" />
          </HStack>
          </VStack>
      </CardBody>
    </ChakraCard>
  );
};

export default Card;
